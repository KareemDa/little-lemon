import React, { useState } from 'react'
import './App.css'

function App() {
	// define state variables
	const [displayValue, setDisplayValue] = useState('')
	const [firstValue, setFirstValue] = useState(null)
	const [operator, setOperator] = useState(null)

	// handle number button clicks
	const handleNumberClick = event => {
		const value = event.target.value
		setDisplayValue(displayValue + value)
	}

	// handle operator button clicks
	const handleOperatorClick = event => {
		const value = parseFloat(displayValue)

		if (firstValue === null) {
			setFirstValue(value)
		} else if (operator !== null) {
			const result = calculate()
			setDisplayValue(result)
			setFirstValue(result)
		}

		setOperator(event.target.value)
		setDisplayValue('')
	}

	// handle equals button click
	const handleEqualsClick = () => {
		const value = parseFloat(displayValue)

		if (firstValue === null) {
			return
		}

		const result = calculate()
		setDisplayValue(result)
		setFirstValue(result)
		setOperator(null)
	}

	// handle clear button click
	const handleClearClick = () => {
		setDisplayValue('')
		setFirstValue(null)
		setOperator(null)
	}

	// calculate result based on current state
	const calculate = () => {
		const secondValue = parseFloat(displayValue)

		if (operator === '+') {
			return firstValue + secondValue
		} else if (operator === '-') {
			return firstValue - secondValue
		} else if (operator === '*') {
			return firstValue * secondValue
		} else if (operator === '/') {
			return firstValue / secondValue
		}

		return secondValue
	}

	return (
		<div className='calculator'>
			<div className='display'>{displayValue}</div>
			<div className='button-row'>
				<button onClick={handleClearClick} className='button clear'>
					C
				</button>
				<button value='/' onClick={handleOperatorClick} className='button operator'>
					&divide;
				</button>
			</div>
			<div className='button-row'>
				<button value='7' onClick={handleNumberClick} className='button number'>
					7
				</button>
				<button value='8' onClick={handleNumberClick} className='button number'>
					8
				</button>
				<button value='9' onClick={handleNumberClick} className='button number'>
					9
				</button>
				<button value='*' onClick={handleOperatorClick} className='button operator'>
					&times;
				</button>
			</div>
			<div className='button-row'>
				<button value='4' onClick={handleNumberClick} className='button number'>
					4
				</button>
				<button value='5' onClick={handleNumberClick} className='button number'>
					5
				</button>
				<button value='6' onClick={handleNumberClick} className='button number'>
					6
				</button>
				<button value='-' onClick={handleOperatorClick} className='button operator'>
					&ndash;
				</button>
			</div>
			<div className='button-row'>
				<button value='1' onClick={handleNumberClick} className='button number'>
					1
				</button>
				<button value='2' onClick={handleNumberClick} className='button number'>
					2
				</button>
				<button value='3' onClick={handleNumberClick} className='button number'>
					3
				</button>
				<button value='+' onClick={handleOperatorClick} className='button operator'>
					+
				</button>
			</div>
			<div className='button-row'>
				<button value='0' onClick={handleNumberClick} className='button number zero'>
					0
				</button>
				<button value='.' onClick={handleNumberClick} className='button number'>
					.
				</button>
				<button onClick={handleEqualsClick} className='button equals'>
					=
				</button>
			</div>
		</div>
	)
}

export default App

import React from 'react'

const Landing = () => {
	return (
		<section className='text-gray-600 bg-slate-100 body-font'>
			<div className='container mx-auto flex px-5 py-24 items-center justify-center flex-col'>
				<div className='lg:w-2/6 md:w-3/6 w-5/6 mb-10'>
					<img className='object-cover object-center rounded-full' alt='avatar' src='https://i.stack.imgur.com/Vmuns.jpg' />
				</div>
				<div className='text-center lg:w-2/3 w-full'>
					<h1 className='title-font sm:text-4xl text-3xl mb-4 font-medium text-gray-900'>Kareem Dabbeet</h1>
					<p className='mb-8 leading-relaxed'>
						Hi there! I'm a front-end web developer who is passionate about building responsive and user-friendly web applications. I'm experienced in HTML,
						CSS, JavaScript, and React.
					</p>
				</div>
			</div>
		</section>
	)
}

export default Landing

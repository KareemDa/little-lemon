import React from 'react'

const ProjectCard = ({ name, description, imageUrl, demoUrl }) => {
	return (
		<div className='flex justify-center w-full p-4 '>
			<div className='h-full border-2 border-gray-200 md:w-1/2 md rounded-lg overflow-hidden'>
				<img className='lg:h-48 md:h-36 w-full object-cover object-center' src={imageUrl} alt={name} />
				<div className='p-6'>
					<h2 className='title-font text-lg font-medium text-gray-900 mb-3'>{name}</h2>
					<h1 className='  title-font font-medium text-gray-500 mb-1 '>{description}</h1>
					<a href={demoUrl} target='_blank' rel='noopener noreferrer' className='text-blue-500 inline-flex items-center mt-2'>
						See Demo
						<svg className='w-4 h-4 ml-2' viewBox='0 0 24 24' stroke='currentColor' strokeWidth='2' fill='none' strokeLinecap='round' strokeLinejoin='round'>
							<path d='M5 12h14' />
							<path d='M12 5l7 7-7 7' />
						</svg>
					</a>
				</div>
			</div>
		</div>
	)
}

export default ProjectCard

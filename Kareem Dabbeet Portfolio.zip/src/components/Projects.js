import React from 'react'
import ProjectCard from './ProjectCard'

const Projects = () => {
	return (
		<section className='py-16 bg-white'>
			<div className='container mx-auto'>
				<h2 className='text-3xl font-semibold text-center'>Projects</h2>
				<div className='grid grid-cols-1 sm:grid-cols-2 gap-8 mt-8'>
					<ProjectCard
						name='CSS Gradient Text Generator'
						description='A tool for generating CSS code for gradient text effects. This project uses vanilla JavaScript and CSS to create beautiful gradient text effects without the need for images or external libraries.'
						imageUrl='https://www.cssgradienttext.com/meta-image.png'
						url='https://www.cssgradienttext.com/'
					/>
					<ProjectCard
						name='Another Basic Project'
						description='This is another basic project description. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'
						imageUrl='https://via.placeholder.com/600x400'
						url='https://www.example.com/'
					/>
				</div>
			</div>
		</section>
	)
}

export default Projects

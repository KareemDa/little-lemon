import BaseHeader from './components/BaseHeader'
import './App.css'
import Landing from './components/Landing'
import Projects from './components/Projects'
import Contact from './components/Cantact'
import BaseFooter from './components/BaseFooter'

function App() {
	return (
		<div className='App'>
			<BaseHeader />

			<Landing />

			<Projects />

			<Contact />

			<BaseFooter />
		</div>
	)
}

export default App
